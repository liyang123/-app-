//
//  ViewController.m
//  Learn
//
//  Created by liyang on 16/3/6.
//  Copyright © 2016年 liyang. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
}
- (IBAction)testTo2 {
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"testApp2://"]]) {
        //后跟的是参数
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"testApp2://canshuma"]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
